/**
|||||||||||||||||||||||||||||||||||||||||||
|||     DIEGO DASSO MIGOTTO 00242243    |||
|||   TRABALHO FINAL DE FCG - INF01047  |||
|||      PROFESSOR MARCELO WALTER       |||
|||      DDII: APPLES AND ORANGES       |||
|||||||||||||||||||||||||||||||||||||||||||
|||     [X] CENARIO                     |||
|||     [X] JOGADOR                     |||
|||     [X] BARREIRA                    |||
|||     [X] BURACO                      |||
|||     [X] RACHADURA                   |||
|||     [X] INIMIGOS                    |||
|||     [X] TRES CAMERAS                |||
|||     [X] MINIMAPA                    |||
|||     [X] DESMORONAMENTO              |||
|||     [X] COLISOES                    |||
|||     [X] VITORIA                     |||
|||     [X] MENU                        |||
|||     [X] MODELOS MELHORADOS          |||
|||     [ ] SOM                         |||
|||||||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||||||
|||              CONTROLES              |||
|||                                     |||
||| w,a,s,d - Movimentacao              |||
||| r - Correr                          |||
||| v - Troca modo da camera            |||
||| z - Diminui distancia da camera     |||
||| x - Aumenta distancia da camera     |||
||| Barra de espaco - Arma de rachadura |||
||| Esc - Sair do jogo                  |||
|||                                     |||
|||||||||||||||||||||||||||||||||||||||||||
 */

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/gl.h>
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>
#include <time.h>
#include "bitmap.h"
#include "glm.h"
#define PI 3.14159265
#define RAND_MAX 3

///INITIALIZATION FUNCTIONS
void mainInit();                ///Chama todas funcoes de inicializacao
void cleanTheHouse();           ///Reset todas as variaveis
void initLowerGrid(int g);      ///Inicializa nivel inferior
void initUpperGrid(int g);      ///Inicializa nivel superior
void initWaterTexture();        ///Inicializa textura da agua
void initGrassTexture();        ///Inicializa textura da grama
void initCrackTexture();        ///Inicializa textura da rachadura
void initHoleTexture();         ///Inicializa textura do buraco
void initLado1Texture();        ///Inicializa 1 lado da skybox
void initLado2Texture();        ///Inicializa 2 lado da skybox
void initLado3Texture();        ///Inicializa 3 lado da skybox
void initLado4Texture();        ///Inicializa 4 lado da skybox
void initModel();               ///Inicializa modelos
void initLight();               ///Inicializa luz
void initFog();                 ///Inicializa nevoa
void printWelcome();            ///Printa no console indentificacao e controles
void createGLUI();              ///
void setWindow();               ///
void setViewport(GLint left, GLint right, GLint bottom, GLint top);
void setSelfStartingPosition(); ///Inicializa posicao dos inimigos
void setEnemyStartingPosition();///Inicializa posicao do jogador
///TEXTURE SETTERS FUNCTIONS
void setTextureWater();         ///Ativa textura da agua
void setTextureGrass();         ///Ativa textura da grama
void setTextureCrack();         ///Ativa textura da rachadura
void setTextureHole();          ///Ativa textura do buraco
void setTextureLado1();         ///Ativa textura do 1 lado da skybox
void setTextureLado2();         ///Ativa textura do 2 lado da skybox
void setTextureLado3();         ///Ativa textura do 3 lado da skybox
void setTextureLado4();         ///Ativa textura do 4 lado da skybox
///LOOP RENDERING FUNCTIONS
void mainRender();              ///Loop com funcoes de atualizacao logicas e funcao de renderizacao
void renderScene();             ///Chama funcao de atualizacao de camera e todas funcoes de renderizacao durante a partida
void renderSelf();              ///Renderiza jogador
void renderSelfArm();           ///Renderiza modelo do braco do jogador
void renderEnemy();             ///Renderiza inimigo
void renderEnemyArm();          ///Renderiza modelo do braco do inimigo
void renderSkybox();             ///Renderiza lado1,lado2,lado3,lado4 cercando da cena
void renderFloor();             ///Renderiza grama, rachaduras e buracos
void renderWater();             ///Renderiza oceano
void renderObstacles();         ///Renderiza caixas
void renderMainTextOverlay();   ///Renderiza overlay de texto com tempo e inimigos vivos
void renderMinimap();           ///Renderiza minimapa
///LOGIC LOOP - STANDARD FUNCTIONS
void gameEnded();               ///Congela teclado
void onKeyDown(unsigned char key, int x, int y);    ///Controle do input
void onKeyUp(unsigned char key, int x, int y);      ///Controle do input
void specialInputDown(int key, int x, int y);    ///Controle do input
void specialInputUp(int key, int x, int y);    ///Controle do input
void onGLUIEvent(int id);
void onWindowReshape(int x, int y);
void mainIdle();
///LOGIC LOOP - MENU FUNCTIONS
void updateMenu();              ///Lógica do Menu
void keyFlags();                ///Controle para teclas pressionadas
void renderMenu();              ///Renderiza menu
void renderMenuText();          ///Renderiza texto do menu
///LOGIC LOOP - GAME AND PLAYER STATE FUNCTIONS
bool checkCollision();          ///Checa colisoes e posicao na grid do jogador
void checkEarthquake();         ///Checa se ha um terreno cercado por rachaduras
void checkCrackquake();         ///Checa se ha rachaduras cercadas por agua
void floodArea(int i, int j, int k);        ///Funcao auxiliar para earthquake
void floodCrackArea(int i, int j, int k);   ///Funca auxiliar para crackquake
void updateTimer();             ///Atualiza tempo do jogo
void updatePosition();          ///Atualiza posicao do jogador
void updateCracker();           ///Gera rachaduras quando jogador aperta barra de espaco
void updateHeightGrid();        ///Atualiza altura de objetos caindo
void updateState();             ///Atualizador geral estado do jogador
void checkCamDistance();        ///Muda distancia da camera
void checkCamMode();            ///Muda modo da camera quando jogador aperta v
void updateCam();               ///Atualiza posicao da camera
void updateMinimapCam();        ///Atualiza posicao da camera do minimapa
///LOGIC LOOP - ENEMIES FUNCIONTS
void checkEnemyCollision();     ///Checa colisao e posicao na grid do inimigo
void updateEnemyPosition();     ///Atualiza posicao do Inimigo
void updateEnemiesState();      ///Atualizador geral do inimigo
void aiChooseSide(int e);       ///Escolhe qual lado inimigo ira se mover
void rotateEnemy(int e);        ///Rotaciona inimigo
void moveEnemy(int e);          ///Move inimigo
///MAIN
int  main(int argc, char **argv);
///
///VARIABLES
///
///WINDOW SETTINGS
int windowWidth = 880;
int windowHeight = 660;
int windowXPos = 50;
int windowYPos = 50;
int mainWindowId = 0;
///GAME SPEED
int fpsSpeed = 5;
int timer = 30;
int timer1 = 3;
int timer2 = 0;
///POSITION AND CAM VARIABLES
int camMode = 0;
float cam1arm = 8.0;
int tpxOffset = 0;
int tpyOffset = 0;
int tpzOffset = 0;
double xOffset = -1.9;
double yOffset = -1.3;
float roty = 0.0f;
float queueRoty = 0.0f;
float rotx = 90.0f;
float speedX = 0.0f;
float speedY = 0.0f;
float speedZ = 0.0f;
float posX = 0.0f;
float posY = 1.02f;
float posZ = 0.0f;
float headPosAux = 0.0f;
float maxSpeed = 0.25f;
float jumpSpeed = 0.06f;
float gravity = 0.004f;
float heightLimit = -5.0f;
float posYOffset = 1.02f;
float nextX = 0.0f;
float nextZ = 0.0f;
float facing = 0.0f;
int face = 0;
///ENEMY VARIABLES
float posXenemy[4] = {0.0f};
float posYenemy[4] = {1.02f, 1.02f, 1.02f, 1.02f};
float posZenemy[4] = {0.0f};
int movesEnemy[4] = { 0 };
float rotYenemy[4] = { 0.0f };
float queueRotYenemy[4] = { 0.0f };
float speedXenemy[4] = { 0 };
float speedYenemy[4] = { 0 };
float speedZenemy[4] = { 0 };
int enemySide[4] = { 0 };
int enemyAiFlag[4] = { false, false, false, false };
bool fellWaterEnemy[4] = { false, false, false, false };
int enemyAlive[4] = { 0 };
int enemiesAlive = 0;
int countDown = 3;
bool countingDown = false;
///COLLISION VARIABLES
float collisionX = 0.0f;
float collisionZ = 0.0f;
bool collisionAux = false;
bool collision = false;
bool onHole = false;
bool fellWater = false;
bool running = false;
///KEYS VARIABLES
bool rightPressed = false;
bool rightFlag = false;
bool leftPressed = false;
bool leftFlag = false;
bool upPressed = false;
bool upFlag = false;
bool downPressed = false;
bool downFlag = false;
bool spacePressed = false;
bool spaceFlag = false;
bool vPressed = false;
bool vFlag = false;
bool zPressed = false;
bool xPressed = false;
bool enterPressed = false;
bool enterFlag = false;
///2D PLANE VARIABLES
int lowerGrid[20][20] = { 0 };
int upperGrid[20][20] = { 0 };
int playerGrid[2] = { 0 };
int enemyGrid[4][2] = { 0 };
int floodGrid[20][20] = { 0 };
int floodAmount[20] = { 0 };
bool cancelFlood = false;
float heightGrid[20][20] = { 0.0f };
float speedGrid[20][20] = { 0.0f };
float waterExtension = 400.0f;
float grassExtension = 4.0f;
///MENU VARIABLES
bool onMenu = true;
float menuCurrent[5] = {0.0,0.0,0.0,0.0,0.0};
int gameSpeed = 3;
int gameStage = 1;
int gameTime = 30;
int gameTime1 = 3;
int gameTime2 = 0;
///MESSAGES
char menuGameTitle[35] = "DIG  DUG  2:  APPLES  AND  ORANGES";
char menuGameSubTitle[27] = "-THE  ORANGE'S  NIGHTMARE-";
char menuPlay[5] = "PLAY";
char menuGameSpeed[15] = "GAME  SPEED  <";
char menuGameStage[15] = "GAME  STAGE  <";
char menuGameTime[13] = "GAME  TIME <";
char menuExit[5] = "EXIT";
char overlay1[9] = "TIMER   ";
char overlay2[16] = "ENEMIES LEFT   ";
char gameOver[11] = "GAME  OVER";
char youWon[13] = "STAGE  CLEAR";
bool wonStage = false;
/// parte de código extraído de "texture.c" por Michael Sweet (OpenGL SuperBible)
/// texture buffers and stuff
int i;                       /* Looping var */
int j;                       /* Looping var */
int k;                       /* Looping var */
int l;                       /* Looping var */
int m;                       /* Looping var */
int n;                       /* Looping var */
int o = 128;                       /* Looping var */
float fn;                       /* Aux var */
BITMAPINFO	*waterbmp;           /* Bitmap information */
GLubyte	    *bits;           /* Bitmap RGB pixels */
GLubyte     *ptr;            /* Pointer into bit buffer */
GLubyte	    *rgba;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr;        /* Pointer into RGBA buffer */
GLubyte     temp;            /* Swapping variable */
GLenum      type;            /* Texture type */
GLuint      texture;         /* Texture object */
BITMAPINFO	*grassbmp;           /* Bitmap information */
GLubyte	    *bits2;           /* Bitmap RGB pixels */
GLubyte     *ptr2;            /* Pointer into bit buffer */
GLubyte	    *rgba2;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr2;        /* Pointer into RGBA buffer */
GLuint      texture2;         /* Texture object */
BITMAPINFO	*lowerGridbmp;           /* Bitmap information */
GLubyte	    *bits3;           /* Bitmap RGB pixels */
GLubyte     *ptr3;            /* Pointer into bit buffer */
GLubyte	    *rgba3;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr3;        /* Pointer into RGBA buffer */
GLuint      texture3;         /* Texture object */
BITMAPINFO	*upperGridbmp;           /* Bitmap information */
GLubyte	    *bits4;           /* Bitmap RGB pixels */
GLubyte     *ptr4;            /* Pointer into bit buffer */
GLubyte	    *rgba4;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr4;        /* Pointer into RGBA buffer */
GLuint      texture4;         /* Texture object */
BITMAPINFO	*crackbmp;           /* Bitmap information */
GLubyte	    *bits5;           /* Bitmap RGB pixels */
GLubyte     *ptr5;            /* Pointer into bit buffer */
GLubyte	    *rgba5;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr5;        /* Pointer into RGBA buffer */
GLuint      texture5;         /* Texture object */
BITMAPINFO	*holebmp;           /* Bitmap information */
GLubyte	    *bits6;           /* Bitmap RGB pixels */
GLubyte     *ptr6;            /* Pointer into bit buffer */
GLubyte	    *rgba6;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr6;        /* Pointer into RGBA buffer */
GLuint      texture6;         /* Texture object */
BITMAPINFO	*lado1bmp;           /* Bitmap information */
GLubyte	    *bits7;           /* Bitmap RGB pixels */
GLubyte     *ptr7;            /* Pointer into bit buffer */
GLubyte	    *rgba7;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr7;        /* Pointer into RGBA buffer */
GLuint      texture7;         /* Texture object */
BITMAPINFO	*lado2bmp;           /* Bitmap information */
GLubyte	    *bits8;           /* Bitmap RGB pixels */
GLubyte     *ptr8;            /* Pointer into bit buffer */
GLubyte	    *rgba8;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr8;        /* Pointer into RGBA buffer */
GLuint      texture8;         /* Texture object */
BITMAPINFO	*lado3bmp;           /* Bitmap information */
GLubyte	    *bits9;           /* Bitmap RGB pixels */
GLubyte     *ptr9;            /* Pointer into bit buffer */
GLubyte	    *rgba9;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr9;        /* Pointer into RGBA buffer */
GLuint      texture9;         /* Texture object */
BITMAPINFO	*lado4bmp;           /* Bitmap information */
GLubyte	    *bits10;           /* Bitmap RGB pixels */
GLubyte     *ptr10;            /* Pointer into bit buffer */
GLubyte	    *rgba10;           /* RGBA pixel buffer */
GLubyte	    *rgbaptr10;        /* Pointer into RGBA buffer */
GLuint      texture10;         /* Texture object */
///MODELS
GLMmodel *modelSelf;
GLMmodel *modelEnemy;
GLMmodel *modelBox;
GLMmodel *modelEyeSelf;
GLMmodel *modelEyeEnemy;

///BACKGROUND COLOR
float backgrundColor[4] = {0.0f,0.0f,0.0f,1.0f};
///OBJECT LOADER
bool C3DObject_Load_New(const char *pszFilename, GLMmodel **model) {
    char aszFilename[256];
    strcpy(aszFilename, pszFilename);

    if (*model) {

    free(*model);
    *model = NULL;
    }

    *model = glmReadOBJ(aszFilename);
    if (!(*model))
    return false;

    glmUnitize(*model);
    //glmScale(model,sFactor); // USED TO SCALE THE OBJECT
    glmFacetNormals(*model);
    glmVertexNormals(*model, 90.0);

    return true;
}
///INITIALIZATION FUNCTIONS
void mainInit() {

    menuCurrent[0] = 1.0f;
    srand(time(NULL));
	glClearColor(1.0,1.0,1.0,0.0);
	glColor3f(0.0f,0.0f,0.0f);
	setWindow();
	setViewport(0, windowWidth, 0, windowHeight);

	// habilita o z-buffer
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_SCISSOR_BOX);
	glEnable(GL_SCISSOR_TEST);

    printf("\n\nCARREGANDO ARQUIVOS DO JOGO");
    initWaterTexture();
    initGrassTexture();
    initCrackTexture();
    initHoleTexture();
    initLado1Texture();
    initLado2Texture();
    initLado3Texture();
    initLado4Texture();
	initModel();
    printWelcome();
	initLight();
	//initFog();

}

void stageInit() {
    cleanTheHouse();
    initLowerGrid(gameStage);
    initUpperGrid(gameStage);
    setEnemyStartingPosition();
	setSelfStartingPosition();
	timer = gameTime;
	fpsSpeed = 16 - gameSpeed*5;
}

void cleanTheHouse() {

    for (i = 0; i < 20; i++){
        for (j = 0; j < 20; j++){
            lowerGrid[i][j] =  0 ;
            upperGrid[i][j] =  0 ;
            heightGrid[i][j] =  0.0f ;
            speedGrid[i][j] =  0.0f ;
        }
    }
    playerGrid[0] = 0 ;
    playerGrid[1] = 0 ;
    for (i = 0; i < 4; i++){
        for (j = 0; j < 2; j++){
            enemyGrid[i][j] = 0;
        }
    }

    collisionX = 0.0f;
    collisionZ = 0.0f;
    collisionAux = false;
    collision = false;
    onHole = false;
    fellWater = false;

    for (i = 0; i<4; i++) {
        posXenemy[i] = 0.0f;
        posYenemy[i] = 1.02f;
        posZenemy[i] = 0.0f;
        movesEnemy[i] = 0;
        rotYenemy[i] = 0.0f;
        queueRotYenemy[i] = 0.0f;
        speedXenemy[i] = 0;
        speedYenemy[i] = 0;
        speedZenemy[i] = 0;
        enemySide[i] = 0;
        enemyAiFlag[i] = false;
        fellWaterEnemy[i] = false;
        enemyAlive[i] = 0;
    }
    enemiesAlive = 0;
    countDown = 3;
    countingDown = false;
    wonStage = false;

    tpxOffset = 0;
    tpyOffset = 0;
    tpzOffset = 0;
    xOffset = -1.9;
    yOffset = -1.3;
    roty = 180.0f;
    queueRoty = 0.0f;
    rotx = 90.0f;
    speedX = 0.0f;
    speedY = 0.0f;
    speedZ = 0.0f;
    posX = 0.0f;
    posY = 1.02f;
    posZ = 0.0f;
    headPosAux = 0.0f;
    maxSpeed = 0.25f;
    jumpSpeed = 0.06f;
    gravity = 0.004f;
    heightLimit = -5.0f;
    posYOffset = 1.02f;
    nextX = 0.0f;
    nextZ = 0.0f;
    facing = 0.0f;
    face = 0;

}

void initLowerGrid(int g) {

    char gs = g +48;
    char lg[15] = "lowerGrid";
    lg[9] = gs;
    strcat(lg,".bmp");

    // Load a texture object (256x256 true color)
    bits3 = LoadDIBitmap(lg, &lowerGridbmp);
    if (bits3 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (lowerGridbmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture3);
	glBindTexture(type, texture3);

    // Create an RGBA image
    rgba3 = (GLubyte *)malloc(lowerGridbmp->bmiHeader.biWidth * lowerGridbmp->bmiHeader.biHeight * 4);

    j = 19;
    k = 19;

    i = lowerGridbmp->bmiHeader.biWidth * lowerGridbmp->bmiHeader.biHeight;
    for( rgbaptr3 = rgba3, ptr3 = bits3;  i > 0; i--, rgbaptr3 += 4, ptr3 += 3)
    {
            rgbaptr3[0] = ptr3[2];     // windows BMP = BGR
            rgbaptr3[1] = ptr3[1];
            rgbaptr3[2] = ptr3[0];
            rgbaptr3[3] = (ptr3[0] + ptr3[1] + ptr3[2]) / 3;

            if (rgbaptr3[0] == 0) {
                lowerGrid[j][k] = 1;
            }

            k = k - 1;
            if (k == -1) {
                k = 19;
                j = j - 1;
            }

    }

    printf("\n\nMAPA INFERIOR..................OK");

}

void initUpperGrid(int g) {

    char gs = g +48;
    char ug[15] = "upperGrid";
    ug[9] = gs;
    strcat(ug,".bmp");
    // Load a texture object (256x256 true color)
    bits4 = LoadDIBitmap(ug, &upperGridbmp);
    if (bits4 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (upperGridbmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture4);
	glBindTexture(type, texture4);

    // Create an RGBA image
    rgba4 = (GLubyte *)malloc(upperGridbmp->bmiHeader.biWidth * upperGridbmp->bmiHeader.biHeight * 4);

    j = 19;
    k = 19;

    i = upperGridbmp->bmiHeader.biWidth * upperGridbmp->bmiHeader.biHeight;
    for( rgbaptr4 = rgba4, ptr4 = bits4;  i > 0; i--, rgbaptr4 += 4, ptr4 += 3)
    {
            rgbaptr4[0] = ptr4[2];     // windows BMP = BGR
            rgbaptr4[1] = ptr4[1];
            rgbaptr4[2] = ptr4[0];
            rgbaptr4[3] = (ptr4[0] + ptr4[1] + ptr4[2]) / 3;

            if (rgbaptr4[0] == 63) {  ///Spawn
                if (lowerGrid[j][k] == 1)
                upperGrid[j][k] = 2;
            }

            if (rgbaptr4[0] == 181) {  ///Obstacle
                if (lowerGrid[j][k] == 1)
                upperGrid[j][k] = 3;
            }

            if (rgbaptr4[0] == 185) {  ///Crack
                if (lowerGrid[j][k] == 1)
                upperGrid[j][k] = 4;
            }

            if (rgbaptr4[0] == 136) {  ///Hole
                if (lowerGrid[j][k] == 1)
                upperGrid[j][k] = 5;
            }

            if (rgbaptr4[0] == 237) {  ///Enemy
                if (lowerGrid[j][k] == 1)
                upperGrid[j][k] = 6;
            }

            k = k - 1;
            if (k == -1) {
                k = 19;
                j = j - 1;
            }

    }

    for (i = 0; i<20; i++) {
        for (j = 0; j<20; j++){
            if (upperGrid[i][j] == 4)
                lowerGrid[i][j] = 4;
            if (upperGrid[i][j] == 5)
                lowerGrid[i][j] = 5;
        }
	}

    printf("\n\nMAPA SUPERIOR..................OK");

}

void initModel() {
	C3DObject_Load_New("ball.obj",&modelSelf);
	C3DObject_Load_New("qmark.obj",&modelBox);
	C3DObject_Load_New("ball2.obj",&modelEnemy);
	C3DObject_Load_New("arm.obj",&modelEyeSelf);
	C3DObject_Load_New("arm2.obj",&modelEyeEnemy);
    printf("\n\nMODELOS........................OK");
}

void initWaterTexture() {
    // Load a texture object (256x256 true color)
    bits = LoadDIBitmap("watertile.bmp", &waterbmp);
    if (bits == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (waterbmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture);
	glBindTexture(type, texture);

    // Create an RGBA image
    rgba = (GLubyte *)malloc(waterbmp->bmiHeader.biWidth * waterbmp->bmiHeader.biHeight * 4);

    i = waterbmp->bmiHeader.biWidth * waterbmp->bmiHeader.biHeight;
    for( rgbaptr = rgba, ptr = bits;  i > 0; i--, rgbaptr += 4, ptr += 3)
    {
            rgbaptr[0] = ptr[2];     // windows BMP = BGR
            rgbaptr[1] = ptr[1];
            rgbaptr[2] = ptr[0];
            rgbaptr[3] = (ptr[0] + ptr[1] + ptr[2]) / 3;
    }

    printf("\n\nTEXTURA DA AGUA................OK");
}

void initGrassTexture() {
    // Load a texture object (256x256 true color)
    bits2 = LoadDIBitmap("grass.bmp", &grassbmp);
    if (bits2 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (grassbmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture2);
	glBindTexture(type, texture2);

    // Create an RGBA image
    rgba2 = (GLubyte *)malloc(grassbmp->bmiHeader.biWidth * grassbmp->bmiHeader.biHeight * 4);

    i = grassbmp->bmiHeader.biWidth * grassbmp->bmiHeader.biHeight;
    for( rgbaptr2 = rgba2, ptr2 = bits2;  i > 0; i--, rgbaptr2 += 4, ptr2 += 3)
    {
            rgbaptr2[0] = ptr2[2];     // windows BMP = BGR
            rgbaptr2[1] = ptr2[1];
            rgbaptr2[2] = ptr2[0];
            rgbaptr2[3] = (ptr2[0] + ptr2[1] + ptr2[2]) / 3;
    }

    printf("\n\nTEXTURA DA GRAMA...............OK");
}

void initCrackTexture() {
    // Load a texture object (256x256 true color)
    bits5 = LoadDIBitmap("crack.bmp", &crackbmp);
    if (bits5 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (crackbmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture5);
	glBindTexture(type, texture5);

    // Create an RGBA image
    rgba5 = (GLubyte *)malloc(crackbmp->bmiHeader.biWidth * crackbmp->bmiHeader.biHeight * 4);

    i = crackbmp->bmiHeader.biWidth * crackbmp->bmiHeader.biHeight;
    for( rgbaptr5 = rgba5, ptr5 = bits5;  i > 0; i--, rgbaptr5 += 4, ptr5 += 3)
    {
            rgbaptr5[0] = ptr5[2];     // windows BMP = BGR
            rgbaptr5[1] = ptr5[1];
            rgbaptr5[2] = ptr5[0];
            rgbaptr5[3] = (ptr5[0] + ptr5[1] + ptr5[2]) / 3;
    }

    printf("\n\nTEXTURA DA RACHADURA...........OK");

}

void initHoleTexture() {
    // Load a texture object (256x256 true color)
    bits6 = LoadDIBitmap("hole.bmp", &holebmp);
    if (bits6 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (holebmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture6);
	glBindTexture(type, texture6);

    // Create an RGBA image
    rgba6 = (GLubyte *)malloc(holebmp->bmiHeader.biWidth * holebmp->bmiHeader.biHeight * 4);

    i = holebmp->bmiHeader.biWidth * holebmp->bmiHeader.biHeight;
    for( rgbaptr6 = rgba6, ptr6 = bits6;  i > 0; i--, rgbaptr6 += 4, ptr6 += 3)
    {
            rgbaptr6[0] = ptr6[2];     // windows BMP = BGR
            rgbaptr6[1] = ptr6[1];
            rgbaptr6[2] = ptr6[0];
            rgbaptr6[3] = (ptr6[0] + ptr6[1] + ptr6[2]) / 3;
    }

    printf("\n\nTEXTURA DO BURACO..............OK");

}

void initLado1Texture() {

    // Load a texture object (256x256 true color)
    bits7 = LoadDIBitmap("lado1.bmp", &lado1bmp);
    if (bits7 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (lado1bmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture7);
	glBindTexture(type, texture7);

    // Create an RGBA image
    rgba7 = (GLubyte *)malloc(lado1bmp->bmiHeader.biWidth * lado1bmp->bmiHeader.biHeight * 4);

    i = lado1bmp->bmiHeader.biWidth * lado1bmp->bmiHeader.biHeight;
    for( rgbaptr7 = rgba7, ptr7 = bits7;  i > 0; i--, rgbaptr7 += 4, ptr7 += 3)
    {
            rgbaptr7[0] = ptr7[2];     // windows BMP = BGR
            rgbaptr7[1] = ptr7[1];
            rgbaptr7[2] = ptr7[0];
            rgbaptr7[3] = (ptr7[0] + ptr7[1] + ptr7[2]) / 3;
    }

    printf("\n\nTEXTURA DO LADO 1..............OK");

}

void initLado2Texture() {

    // Load a texture object (256x256 true color)
    bits8 = LoadDIBitmap("lado2.bmp", &lado2bmp);
    if (bits8 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (lado2bmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture8);
	glBindTexture(type, texture8);

    // Create an RGBA image
    rgba8 = (GLubyte *)malloc(lado2bmp->bmiHeader.biWidth * lado2bmp->bmiHeader.biHeight * 4);

    i = lado2bmp->bmiHeader.biWidth * lado2bmp->bmiHeader.biHeight;
    for( rgbaptr8 = rgba8, ptr8 = bits8;  i > 0; i--, rgbaptr8 += 4, ptr8 += 3)
    {
            rgbaptr8[0] = ptr8[2];     // windows BMP = BGR
            rgbaptr8[1] = ptr8[1];
            rgbaptr8[2] = ptr8[0];
            rgbaptr8[3] = (ptr8[0] + ptr8[1] + ptr8[2]) / 3;
    }

    printf("\n\nTEXTURA DO LADO 2..............OK");

}

void initLado3Texture() {

    // Load a texture object (256x256 true color)
    bits9 = LoadDIBitmap("lado3.bmp", &lado3bmp);
    if (bits9 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (lado3bmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture9);
	glBindTexture(type, texture9);

    // Create an RGBA image
    rgba9 = (GLubyte *)malloc(lado3bmp->bmiHeader.biWidth * lado3bmp->bmiHeader.biHeight * 4);

    i = lado3bmp->bmiHeader.biWidth * lado3bmp->bmiHeader.biHeight;
    for( rgbaptr9 = rgba9, ptr9 = bits9;  i > 0; i--, rgbaptr9 += 4, ptr9 += 3)
    {
            rgbaptr9[0] = ptr9[2];     // windows BMP = BGR
            rgbaptr9[1] = ptr9[1];
            rgbaptr9[2] = ptr9[0];
            rgbaptr9[3] = (ptr9[0] + ptr9[1] + ptr9[2]) / 3;
    }

    printf("\n\nTEXTURA DO LADO 3..............OK");

}

void initLado4Texture() {

    // Load a texture object (256x256 true color)
    bits10 = LoadDIBitmap("lado4.bmp", &lado4bmp);
    if (bits10 == (GLubyte *)0) {
		printf ("Error loading texture!\n\n");
		return;
	}
    // Figure out the type of texture
    if (lado4bmp->bmiHeader.biHeight == 1)
      type = GL_TEXTURE_1D;
    else
      type = GL_TEXTURE_2D;

    // Create and bind a texture object
    glGenTextures(1, &texture10);
	glBindTexture(type, texture10);

    // Create an RGBA image
    rgba10 = (GLubyte *)malloc(lado4bmp->bmiHeader.biWidth * lado4bmp->bmiHeader.biHeight * 4);

    i = lado4bmp->bmiHeader.biWidth * lado4bmp->bmiHeader.biHeight;
    for( rgbaptr10 = rgba10, ptr10 = bits10;  i > 0; i--, rgbaptr10 += 4, ptr10 += 3)
    {
            rgbaptr10[0] = ptr10[2];     // windows BMP = BGR
            rgbaptr10[1] = ptr10[1];
            rgbaptr10[2] = ptr10[0];
            rgbaptr10[3] = (ptr10[0] + ptr10[1] + ptr10[2]) / 3;
    }

    printf("\n\nTEXTURA DO LADO 4..............OK");

}

void initLight() {
    glEnable(GL_LIGHTING );
	glEnable( GL_LIGHT0 );

	GLfloat light_ambient[] = { 0.001, 0.001, 0.001, 1.0 };
	GLfloat light_diffuse[] = { 0.0, 0.0, 0.0, 0.0 };
	GLfloat light_specular[] = { 0.0, 0.0, 0.0, 0.0 };
	GLfloat light_position1[] = { 0.0, 30.0, 0.0, 0.0 };

	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position1);

	glEnable( GL_LIGHT2 );

	GLfloat light_ambient2[] = { 0.0, 0.0, 0.0, 0.0 };
	GLfloat light_diffuse2[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_specular2[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_position2[] = { 0, 30.0, 0, 1.0 };
    GLfloat attenuation = 0.02;

	glLightfv(GL_LIGHT2, GL_AMBIENT, light_ambient2);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, light_diffuse2);
	glLightfv(GL_LIGHT2, GL_SPECULAR, light_specular2);
	glLightfv(GL_LIGHT2, GL_POSITION, light_position2);
	glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, attenuation);

	//glEnable( GL_LIGHT3 );

	GLfloat light_ambient3[] = { 0.0, 0.0, 0.0, 0.0 };
	GLfloat light_diffuse3[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_specular3[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_position3[] = { grassExtension, 30.0, -grassExtension, 1.0 };

	glLightfv(GL_LIGHT3, GL_AMBIENT, light_ambient3);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, light_diffuse3);
	glLightfv(GL_LIGHT3, GL_SPECULAR, light_specular3);
	glLightfv(GL_LIGHT3, GL_POSITION, light_position3);
	glLightf(GL_LIGHT3, GL_LINEAR_ATTENUATION, attenuation);

}

void initFog() {

    GLuint filter;                      // Which Filter To Use              // Which Fog To Use
    GLfloat fogColor[4]= {0.5f, 0.5f, 0.5f, 1.0f};      // Fog Color

    glFogi(GL_FOG_MODE, GL_EXP);        // Fog Mode
    glFogfv(GL_FOG_COLOR, fogColor);            // Set Fog Color
    glFogf(GL_FOG_DENSITY, 0.005f);              // How Dense Will The Fog Be
    glHint(GL_FOG_HINT, GL_NICEST);          // Fog Hint Value
    glFogf(GL_FOG_START, 1.0f);             // Fog Start Depth
    glFogf(GL_FOG_END, 1000.0f);               // Fog End Depth
    glEnable(GL_FOG);                   // Enables GL_FOG

}

void printWelcome() {

    printf("\n\n|||||||||||||||||||||||||||||||||||||||||||");
    printf("\n|||     DIEGO DASSO MIGOTTO 00242243    |||");
    printf("\n|||   TRABALHO FINAL DE FCG - INF01047  |||");
    printf("\n|||      PROFESSOR MARCELO WALTER       |||");
    printf("\n|||      DDII: APPLES AND ORANGES       |||");
    printf("\n|||||||||||||||||||||||||||||||||||||||||||");
    printf("\n|||     [X] CENARIO                     |||");
    printf("\n|||     [X] JOGADOR                     |||");
    printf("\n|||     [X] BARREIRA                    |||");
    printf("\n|||     [X] BURACO                      |||");
    printf("\n|||     [X] RACHADURA                   |||");
    printf("\n|||     [X] INIMIGOS                    |||");
    printf("\n|||     [X] TRES CAMERAS                |||");
    printf("\n|||     [X] MINIMAPA                    |||");
    printf("\n|||     [X] DESMORONAMENTO              |||");
    printf("\n|||     [X] COLISOES                    |||");
    printf("\n|||     [X] VITORIA                     |||");
    printf("\n|||     [X] MENU                        |||");
    printf("\n|||     [X] MODELOS MELHORADOS          |||");
    printf("\n|||     [ ] SOM                         |||");
    printf("\n|||||||||||||||||||||||||||||||||||||||||||");
    printf("\n|||||||||||||||||||||||||||||||||||||||||||");
    printf("\n|||              CONTROLES              |||");
    printf("\n|||                                     |||");
    printf("\n||| w,a,s,d - Movimentacao              |||");
    printf("\n||| r - Correr                          |||");
    printf("\n||| v - Troca modo da camera            |||");
    printf("\n||| z - Diminui distancia da camera     |||");
    printf("\n||| x - Aumenta distancia da camera     |||");
    printf("\n||| Barra de espaco - Arma de rachadura |||");
    printf("\n||| Esc - Sair do jogo                  |||");
    printf("\n|||                                     |||");
    printf("\n|||||||||||||||||||||||||||||||||||||||||||");

}

void setSelfStartingPosition() {

    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if (upperGrid[k][l] == 2) {
                i = k;
                j = l;
                k = 20;
                l = 20;
            }
        }
    }

    posX = posX + i*grassExtension;
    posZ = posZ + j*grassExtension;

}

void setEnemyStartingPosition() {

    i = 0;

    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if (upperGrid[k][l] == 6) {
                    enemiesAlive = enemiesAlive + 1;
                    enemyAlive[i] = 1;
                    posXenemy[i] = k*grassExtension;
                    posZenemy[i] = l*grassExtension;
                    i = i + 1;
            }
        }
    }

}

void setWindow() {

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f,(GLfloat)windowWidth/(GLfloat)windowHeight,0.1f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(posX,posY + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)),posZ,
		posX + sin(roty*PI/180),posY + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)) + cos(rotx*PI/180),posZ -cos(roty*PI/180),
		0.0,1.0,0.0);
}

void setViewport(GLint left, GLint right, GLint bottom, GLint top) {
	glViewport(left, bottom, right - left, top - bottom);
}

///TEXTURE SETTERS FUNCTIONS
void setTextureWater() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, waterbmp->bmiHeader.biWidth, waterbmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba );

}

void setTextureGrass() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, grassbmp->bmiHeader.biWidth, grassbmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba2);

}

void setTextureCrack() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, crackbmp->bmiHeader.biWidth, crackbmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba5);

}

void setTextureHole() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, holebmp->bmiHeader.biWidth, holebmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba6);

}

void setTextureLado1() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, lado1bmp->bmiHeader.biWidth, lado1bmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba7);

}

void setTextureLado2() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, lado2bmp->bmiHeader.biWidth, lado2bmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba8);

}

void setTextureLado3() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, lado3bmp->bmiHeader.biWidth, lado3bmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba9);

}

void setTextureLado4() {

	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(type, 0, 4, lado4bmp->bmiHeader.biWidth, lado4bmp->bmiHeader.biHeight,
                  0, GL_RGBA, GL_UNSIGNED_BYTE, rgba10);

}

///MENU LOOP FUNCTIONS
void updateMenu() {

    keyFlags();

    if (menuCurrent[0] == 1.0) {
        if (enterPressed) {
            stageInit();
            onMenu = false;
        }
        if (downPressed) {
            menuCurrent[0] = 0.0;
            menuCurrent[1] = 1.0;
        }
    } else

    if (menuCurrent[1] == 1.0) {
        if (upPressed) {
            menuCurrent[0] = 1.0;
            menuCurrent[1] = 0.0;
        }
        if (downPressed) {
            menuCurrent[1] = 0.0;
            menuCurrent[2] = 1.0;
        }
        if (leftPressed) {
            if (gameStage > 1)
                gameStage = gameStage - 1;
        }
        if (rightPressed) {
            if (gameStage < 9)
                gameStage = gameStage + 1;
        }
    } else

    if (menuCurrent[2] == 1.0) {
        if (upPressed) {
            menuCurrent[1] = 1.0;
            menuCurrent[2] = 0.0;
        }
        if (downPressed) {
            menuCurrent[2] = 0.0;
            menuCurrent[3] = 1.0;
        }
        if (leftPressed) {
            if (gameTime == 45) {
                gameTime = 30;
                gameTime1 = 3;
                gameTime2 = 0;
            }
            if (gameTime == 60) {
                gameTime = 45;
                gameTime1 = 4;
                gameTime2 = 5;
            }
        }
        if (rightPressed) {
            if (gameTime == 45) {
                gameTime = 60;
                gameTime1 = 6;
                gameTime2 = 0;
            }
            if (gameTime == 30) {
                gameTime = 45;
                gameTime1 = 4;
                gameTime2 = 5;
            }
        }
    } else

    if (menuCurrent[3] == 1.0) {
        if (upPressed) {
            menuCurrent[2] = 1.0;
            menuCurrent[3] = 0.0;
        }
        if (downPressed) {
            menuCurrent[3] = 0.0;
            menuCurrent[4] = 1.0;
        }
        if (leftPressed) {
            if (gameSpeed > 1)
                gameSpeed = gameSpeed - 1;
        }
        if (rightPressed) {
            if (gameSpeed < 3)
                gameSpeed = gameSpeed + 1;
        }
    } else

    if (menuCurrent[4] == 1.0) {
        if (upPressed) {
            menuCurrent[3] = 1.0;
            menuCurrent[4] = 0.0;
        }
        if (enterPressed)
            exit(0);
    }

}

void keyFlags() {

    if (upPressed) {
        if (upFlag) {
            upPressed = false;
        }
        upFlag = true;
	} else {
        upFlag = false;
	}

	if (leftPressed) {
        if (leftFlag) {
            leftPressed = false;
        }
        leftFlag = true;
	} else {
        leftFlag = false;
	}

	if (rightPressed) {
        if (rightFlag) {
            rightPressed = false;
        }
        rightFlag = true;
	} else {
        rightFlag = false;
	}

	if (downPressed) {
        if (downFlag) {
            downPressed = false;
        }
        downFlag = true;
	} else {
        downFlag = false;
	}

	if (enterPressed) {
        if (enterFlag) {
            enterPressed = false;
        }
        enterFlag = true;
	} else {
        enterFlag = false;
	}

}

void renderMenu() {

    glClearColor(backgrundColor[0],backgrundColor[1],backgrundColor[2],backgrundColor[3]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // limpar o depth buffer

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    glDisable(GL_LIGHTING);
	renderMenuText();
	glEnable(GL_LIGHTING);

}

void renderMenuText() {

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, windowWidth, 0.0, windowHeight);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glColor3d(1.0, 0.0, 0.0);
    glRasterPos2i(windowWidth/2 - 200, windowHeight - windowHeight/8);
    for (i = 0; i<34; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuGameTitle[i]);
    }

    glColor3d(1.0, 0.0, 0.0);
    glRasterPos2i(windowWidth/2 - 160, windowHeight - windowHeight/8 - 50);
    for (i = 0; i<26; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuGameSubTitle[i]);
    }

    glColor3d(1.0, menuCurrent[0], menuCurrent[0]);
    glRasterPos2i(windowWidth/2 - 20, windowHeight - windowHeight/7 - 150);
    for (i = 0; i<4; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuPlay[i]);
    }

    glColor3d(1.0, menuCurrent[1], menuCurrent[1]);
    glRasterPos2i(windowWidth/2 - 100, windowHeight - windowHeight/7 - 190);
    for (i = 0; i<14; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuGameStage[i]);
    }
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, gameStage +48);
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 62);

    glColor3d(1.0, menuCurrent[2], menuCurrent[2]);
    glRasterPos2i(windowWidth/2 - 90, windowHeight - windowHeight/7 - 230);
    for (i = 0; i<12; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuGameTime[i]);
    }
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, gameTime1 +48);
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, gameTime2 +48);
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 62);

    glColor3d(1.0, menuCurrent[3], menuCurrent[3]);
    glRasterPos2i(windowWidth/2 - 100, windowHeight - windowHeight/7 - 270);
    for (i = 0; i<14; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuGameSpeed[i]);
    }
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, gameSpeed +48);
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 62);

    glColor3d(1.0, menuCurrent[4], menuCurrent[4]);
    glRasterPos2i(windowWidth/2 - 20, windowHeight - windowHeight/7 - 310);
    for (i = 0; i<4; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, menuExit[i]);
    }

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();


}

///GAME LOOP FUNCTIONS
void updateCam() {

    if (queueRoty > 0) {

        queueRoty = queueRoty - 10.0f;
        roty = roty + 10.0f;

    }

    if (queueRoty < 0) {

        queueRoty = queueRoty + 10.0f;
        roty = roty - 10.0f;

    }

    switch (camMode) {

    case 0:

	gluLookAt(posX,posY + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)),posZ,
		posX + sin(roty*PI/180),posY + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)) + cos(rotx*PI/180),posZ -cos(roty*PI/180),
		0.0,1.0,0.0);

    break;

    case 1:

	gluLookAt(posX - cam1arm*sin(roty*PI/180),1.02 + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)) + cam1arm/2,posZ - cam1arm*(-cos(roty*PI/180)),
		posX + sin(roty*PI/180),1.02 + posYOffset + 0.025 * std::abs(sin(headPosAux*PI/180)) + cos(rotx*PI/180),posZ -cos(roty*PI/180),
		0.0,1.0,0.0);

    break;

    case 2:

	gluLookAt(posX,1.02 + posYOffset + 20.0 + cam1arm,posZ,posX+0.1,1.02,posZ,0.0,1.0,0.0);

    break;

    }
}

void renderMainTextOverlay() {

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, windowWidth, 0.0, windowHeight);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glColor3d(1.0, 1.0, 1.0);
    glRasterPos2i(windowWidth/10, windowHeight - windowHeight/10);

    for (i = 0; i<8; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, overlay1[i]);
    }
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, timer1+48);
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, timer2+48);

    glRasterPos2i(2*windowWidth/3, windowHeight - windowHeight/10);

    for (i = 0; i<15; i++){
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, overlay2[i]);
    }
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, enemiesAlive+48);

    if (fellWater) {
        glRasterPos2i(windowWidth/2 - 80, windowHeight/2);
        for (i = 0; i<10; i++){
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, gameOver[i]);
        }
    }

    if (enemiesAlive == 0 && fellWater == false) {
        glRasterPos2i(windowWidth/2 - 60, windowHeight/2);
        for (i = 0; i<12; i++){
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, youWon[i]);
        }
    }

    if (countingDown) {
        glRasterPos2i(windowWidth/2 - 5, windowHeight/2 - 60);
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, countDown +48);
    }

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

}

void renderSkybox() {

    setTextureLado1();

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(0.0f, 0.0f, 390.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);

    glBegin(GL_QUADS);

        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(400.0f, 400.0f, 0.0f);

        glTexCoord2f(0.0f, 1.0f);   // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(-400.0f, 400.0f, 0.0f);

        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(-400.0f, -400.0f, 0.0f);

        glTexCoord2f(1.0f, 0.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(400.0f, -400.0f, 0.0f);

        glEnd();

	glDisable(type);


	glPopMatrix();

	setTextureLado2();

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(390.0f, 0.0f, 0.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 1.0f);   // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, 400.0f, -400.0f);

        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, 400.0f, 400.0f);

        glTexCoord2f(1.0f, 0.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, -400.0f, 400.0f);

        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, -400.0f, -400.0f);

        glEnd();

	glDisable(type);


	glPopMatrix();

	setTextureLado3();

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(0.0f, 0.0f, -390.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 1.0f);   // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(-400.0f, 400.0f, 0.0f);

        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(400.0f, 400.0f, 0.0f);

        glTexCoord2f(1.0f, 0.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(400.0f, -400.0f, 0.0f);

        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
        glNormal3f(0.0f,0.0f,1.0f);
        glVertex3f(-400.0f, -400.0f, 0.0f);

        glEnd();

	glDisable(type);


	glPopMatrix();

	setTextureLado4();

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(-390.0f, 0.0f, 0.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 1.0f);   // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, 400.0f, -400.0f);

        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, 400.0f, 400.0f);

        glTexCoord2f(1.0f, 0.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, -400.0f, 400.0f);

        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
        glNormal3f(1.0f,0.0f,0.0f);
        glVertex3f(0.0f, -400.0f, -400.0f);

        glEnd();

	glDisable(type);


	glPopMatrix();

}

void renderWater() {
	// set things up to render the floor with the texture

    setTextureWater();

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(-(float)waterExtension/2.0f, -5.0f, -(float)waterExtension/2.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);
    int xQuads = 40;
    int zQuads = 40;
    for (int i = 0; i < xQuads; i++) {
        for (int j = 0; j < zQuads; j++) {
            glBegin(GL_QUADS);
                glTexCoord2f(1.0f, 0.0f);   // coords for the texture
                glNormal3f(0.0f,1.0f,0.0f);
                glVertex3f(i * (float)waterExtension/xQuads, 0.0f, (j+1) * (float)waterExtension/zQuads);

                glTexCoord2f(0.0f, 0.0f);  // coords for the texture
                glNormal3f(0.0f,1.0f,0.0f);
                glVertex3f((i+1) * (float)waterExtension/xQuads, 0.0f, (j+1) * (float)waterExtension/zQuads);

                glTexCoord2f(0.0f, 1.0f);  // coords for the texture
                glNormal3f(0.0f,1.0f,0.0f);
                glVertex3f((i+1) * (float)waterExtension/xQuads, 0.0f, j * (float)waterExtension/zQuads);

                glTexCoord2f(1.0f, 1.0f);  // coords for the texture
                glNormal3f(0.0f,1.0f,0.0f);
                glVertex3f(i * (float)waterExtension/xQuads, 0.0f, j * (float)waterExtension/zQuads);

            glEnd();
        }
    }

	glDisable(type);


	glPopMatrix();
}

void renderFloor() {
	// set things up to render the floor with the texture

	glShadeModel(GL_SMOOTH);
	glEnable(type);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();

    glTranslatef(-(float)grassExtension/2.0f, 0.0f, -(float)grassExtension/2.0f);

    glColor4f(1.0f,1.0f,1.0f,1.0f);
    int xQuads = 1;
    int zQuads = 1;

    setTextureGrass();

    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if (lowerGrid[k][l] == 1 || lowerGrid[k][l] == 7) {
                glTranslatef(0, heightGrid[k][l], 0);
                for (int i = 0; i < xQuads; i++) {
                    for (int j = 0; j < zQuads; j++) {
                        glBegin(GL_QUADS);
                        glTexCoord2f(1.0f, 0.0f);   // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                    glEnd();
                    }
                }
                glTranslatef(0, -heightGrid[k][l], 0);
            }
            glTranslatef(0.0, 0.0, (float)grassExtension);
        }
        glTranslatef((float)grassExtension, 0.0, 0.0);
        glTranslatef(0.0, 0.0, -20*(float)grassExtension);
    }

    glTranslatef(-20*(float)grassExtension, 0.0, 0.0);

    setTextureCrack();

    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if ((lowerGrid[k][l] == 4) || (lowerGrid[k][l] == 8)) {
                glTranslatef(0, heightGrid[k][l], 0);
                for (int i = 0; i < xQuads; i++) {
                    for (int j = 0; j < zQuads; j++) {
                        glBegin(GL_QUADS);
                        glTexCoord2f(1.0f, 0.0f);   // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                    glEnd();
                    }
                }
                glTranslatef(0, -heightGrid[k][l], 0);
            }
            glTranslatef(0.0, 0.0, (float)grassExtension);
        }
        glTranslatef((float)grassExtension, 0.0, 0.0);
        glTranslatef(0.0, 0.0, -20*(float)grassExtension);
    }

    glTranslatef(-20*(float)grassExtension, 0.0, 0.0);

    setTextureHole();

    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if ((lowerGrid[k][l] == 5) || (lowerGrid[k][l] == 9)) {
                glTranslatef(0, heightGrid[k][l], 0);
                for (int i = 0; i < xQuads; i++) {
                    for (int j = 0; j < zQuads; j++) {
                        glBegin(GL_QUADS);
                        glTexCoord2f(1.0f, 0.0f);   // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 0.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, (j+1) * (float)grassExtension/zQuads);

                        glTexCoord2f(0.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f((i+1) * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                        glTexCoord2f(1.0f, 1.0f);  // coords for the texture
                        glNormal3f(0.0f,1.0f,0.0f);
                        glVertex3f(i * (float)grassExtension/xQuads, 0.0f, j * (float)grassExtension/zQuads);

                    glEnd();
                    }
                }
                glTranslatef(0, -heightGrid[k][l], 0);
            }
            glTranslatef(0.0, 0.0, (float)grassExtension);
        }
        glTranslatef((float)grassExtension, 0.0, 0.0);
        glTranslatef(0.0, 0.0, -20*(float)grassExtension);
    }

	glDisable(type);


	glPopMatrix();
}

void renderObstacles() {

    glPushMatrix();

    glTranslatef(0.0, 1.5, 0.0);
    for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {
            if (upperGrid[k][l] == 3){
                glTranslatef(0.0, heightGrid[k][l], 0.0);
                glScalef(1.5, 1.5, 1.5);
                glmDraw(modelBox, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
                glScalef(0.66666, 0.66666, 0.66666);
                glTranslatef(0.0, -heightGrid[k][l], 0.0);
            }
            glTranslatef(0.0, 0.0, (float)grassExtension);
        }
        glTranslatef(0.0, 0.0, -20*(float)grassExtension);
        glTranslatef((float)grassExtension, 0.0, 0.0);
    }

	glPopMatrix();

}

void renderSelf() {

    glPushMatrix();

    glTranslatef(0.0, 1.0, 0.0);

    glTranslatef(posX, posY - 1.02f, posZ);

    glRotatef(0, 0.0, 1.0, 0.0);
    glRotatef((180-roty), 0.0, 1.0, 0.0);

    glmDraw(modelSelf, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);

    glTranslatef(0.0, 0.6, 0.8);
    glScalef(0.2, 0.2, 0.2);
    glmDraw(modelSelf, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
    glScalef(5.0, 5.0, 5.0);
    glTranslatef(0.0, -0.6, -0.8);

    glRotatef(-(180-roty), 0.0, 1.0, 0.0);
    glRotatef(-roty, 0.0, 1.0, 0.0);

    glTranslatef (-0.5, 0.5, -0.5);
    glScalef(0.5, 0.5, 0.5);
    renderSelfArm();
    glScalef(2.0, 2.0, 2.0);

    glTranslatef (+1.0, 0.0, 0.0);
    glScalef(0.5, 0.5, 0.5);
    renderSelfArm();
    glScalef(2.0, 2.0, 2.0);

	glPopMatrix();

}

void renderSelfArm() {
    glmDraw(modelEyeSelf, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
}

void renderEnemy(float posXe, float posYe, float posZe, float rotYe) {

    glPushMatrix();

    glTranslatef(0.0, 1.0, 0.0);

    glTranslatef(posXe, posYe - 1.02f, posZe);

    glRotatef(0, 0.0, 1.0, 0.0);
    glRotatef(-rotYe, 0.0, 1.0, 0.0);

    glmDraw(modelEnemy, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);

    glTranslatef (-0.5, 0.5, -0.5);
    glScalef(0.5, 0.5, 0.5);
    renderEnemyArm();
    glScalef(2.0, 2.0, 2.0);

    glTranslatef (+1.0, 0.0, 0.0);
    glScalef(0.5, 0.5, 0.5);
    renderEnemyArm();
    glScalef(2.0, 2.0, 2.0);

	glPopMatrix();

}

void renderEnemyArm() {
    glmDraw(modelEyeEnemy, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
}

void renderAllEnemies() {

    for (i = 0; i<4; i++){
        if (enemyAlive[i] == 1)
            renderEnemy(posXenemy[i], posYenemy[i], posZenemy[i], rotYenemy[i]);
    }

}

void renderScene() {

	glClearColor(backgrundColor[0],backgrundColor[1],backgrundColor[2],backgrundColor[3]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // limpar o depth buffer

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    updateCam();

    renderObstacles();
    renderSelf();
    renderAllEnemies();
    glBindTexture(type, texture);
    renderSkybox();
	renderWater();
	renderFloor();

    glDisable(GL_LIGHTING);
	renderMainTextOverlay();
    glEnable(GL_LIGHTING);
}

void renderMinimap() {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // limpar o depth buffer

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	updateMinimapCam();

    renderObstacles();
    renderSelf();
    renderAllEnemies();
    glBindTexture(type, texture);
    renderSkybox();
	renderWater();
	renderFloor();

}

void updateMinimapCam() {

    gluLookAt(posX,50.0,posZ,posX+0.1,1.00,posZ,0.0,1.0,0.0);

}

bool checkCollision() {

    onHole = false;
    collisionAux = false;
    collisionX = 0;
    collisionZ = 0;
    collisionX = collisionX - (float)grassExtension/2;
    collisionZ = collisionZ - (float)grassExtension/2;

   for (k = 0; k<20; k++) {
        for (l = 0; l<20; l++) {

                if((collisionX < posX) && (posX < collisionX + (float)grassExtension) && (collisionZ < posZ) && (posZ < collisionZ + (float)grassExtension)) {
                    playerGrid[0] = k;
                    playerGrid[1] = l;
                }

                if(upperGrid[k][l] == 3){
                        if((collisionX < nextX) && (nextX < collisionX + (float)grassExtension) && (collisionZ < nextZ) && (nextZ < collisionZ + (float)grassExtension)){
                            collisionAux = true;
                        }
                }
                if(upperGrid[k][l] == 5){
                        if((collisionX < posX) && (posX < collisionX + (float)grassExtension) && (collisionZ < posZ) && (posZ < collisionZ + (float)grassExtension)){
                            onHole = true;
                        }
                }
                if(lowerGrid[k][l] == 0 || lowerGrid[k][l] == 7 || lowerGrid[k][l] == 8 || lowerGrid[k][l] == 9){
                        if((collisionX < nextX) && (nextX < collisionX + (float)grassExtension) && (collisionZ < nextZ) && (nextZ < collisionZ + (float)grassExtension)){
                            fellWater = true;
                        }
                }
                collisionZ = collisionZ + (float)grassExtension;
        }
        collisionZ = collisionZ - (float)grassExtension*20;
        collisionX = collisionX + (float)grassExtension;
    }

    fn = 0.0f;

    for (i = 0; i<4; i++) {
        fn = ((posX - posXenemy[i])*(posX - posXenemy[i])) + ((posZ - posZenemy[i])*(posZ - posZenemy[i]));
        fn = sqrt(fn);
        if (fn < 1.8)
            fellWater = true;
    }

   return collisionAux;

}

void updateState() {

    updateHeightGrid();
    if (enemiesAlive == 0 && !fellWater)
            wonStage = true;
    else
        wonStage = false;
    if (fellWater || enemiesAlive == 0)
        gameEnded();
    else
        updateTimer();
	updatePosition();
    checkCamDistance();
    checkCamMode();
	updateCracker();
	checkEarthquake();
	checkCrackquake();

}

void updateTimer() {

    m = m + 1;
	if (m == 79 && (timer > 0)) {
        m = 0;
        timer = timer - 1;
	}

	if (timer == 0)
        fellWater = true;

    timer1 = timer / 10;
    timer2 = timer % 10;

}

void updatePosition() {

    if (upPressed || downPressed) {

		if (running) {
			speedX = 0.05 * sin(roty*PI/180) * 2;
			speedZ = -0.05 * cos(roty*PI/180) * 2;
		} else {
			speedX = 0.05 * sin(roty*PI/180);
			speedZ = -0.05 * cos(roty*PI/180);
		}

		// efeito de "sobe e desce" ao andar
		headPosAux += 8.5f;
		if (headPosAux > 180.0f) {
			headPosAux = 0.0f;
		}

        if (upPressed) {
            nextX = posX + speedX;
            nextZ = posZ + speedZ;
            collision = checkCollision();
            if (!collision){
                posX = nextX;
                posZ = nextZ;
            }
        } else {
            nextX = posX - speedX;
            nextZ = posZ - speedZ;
            collision = checkCollision();
            if (!collision){
                posX = nextX;
                posZ = nextZ;
            }
        }


	} else {
		// parou de andar, para com o efeito de "sobe e desce"
		headPosAux = fmod(headPosAux, 90) - 1 * headPosAux / 90;
		headPosAux -= 4.0f;
		if (headPosAux < 0.0f) {
			headPosAux = 0.0f;
		}
	}


	posY = posY - speedY;
	if (posY < heightLimit) {
		posY = heightLimit;
		speedY = 0.0f;
	}

	if (fellWater){
        speedY = speedY + 0.01;
	}

    posYOffset += 0.01;
    if (posYOffset > 1.02) {
        posYOffset = 1.02;
    }

	if (leftPressed) {

        if (leftFlag) {

            queueRoty = queueRoty - 90;

        }

        leftFlag = false;

	} else {

        leftFlag = true;

	}

	if (rightPressed) {

        if (rightFlag) {

            queueRoty = queueRoty + 90;

        }

        rightFlag = false;

	} else {

        rightFlag = true;

	}

}

void checkCamMode() {

    if (vPressed) {

        if (vFlag) {

            camMode = camMode + 1;
            if (camMode == 3)
                camMode = 0;

        }

        vFlag = false;

	} else {

        vFlag = true;

	}

}

void updateCracker() {

    facing = fmod(roty, 360.0f);

    if ((facing < -130.0f && facing > -230.0f) || (facing > 140.0f && facing < 250.0f))
        face = 2;
    else if ((facing > 40.0f && facing < 140.0f) || (facing < -220.0f && facing > -320.0f))
        face = 1;
    else if ((facing > 310.0f || facing < -310.0f) || (facing > -50.0f && facing < 50.0f))
        face = 0;
    else if ((facing > 220.0f && facing < 320.0f) || (facing < -40.0f && facing > -140.0f))
        face = 3;

	if (spacePressed) {

        if (spaceFlag && onHole) {

            i = playerGrid[0];
            j = playerGrid[1];

            switch (face){
                case 0:
                    while (lowerGrid[i][j-1] == 1){
                        lowerGrid[i][j-1] = 4;
                        j = j - 1;
                    }
                    break;
                case 1:
                    while (lowerGrid[i+1][j] == 1){
                        lowerGrid[i+1][j] = 4;
                        i = i + 1;
                    }
                    break;
                case 2:
                    while (lowerGrid[i][j+1] == 1){
                        lowerGrid[i][j+1] = 4;
                        j = j + 1;
                    }
                    break;
                case 3:
                    while (lowerGrid[i-1][j] == 1){
                        lowerGrid[i-1][j] = 4;
                        i = i - 1;
                    }
                    break;

            }
        }

        spaceFlag = false;

	} else {

        spaceFlag = true;

	}

}

void checkEarthquake() {

    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            floodGrid[i][j] = 0;
        }
    }

    for (i = 0; i < 20; i++) {
        floodAmount[i] = 0;
    }

    k = 1;
    l = 1;

    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            if ((lowerGrid[i][j] == 1) && (floodGrid[i][j] == 0)) {
                floodArea(i,j,k);
                k = k + 1;
            }
        }
    }

    for (i = 1; i<k; i++){
        if (floodAmount[i] < floodAmount[l])
            l = i;
    }

    if (k > 2){
        for (i = 0; i < 20; i++) {
            for (j = 0; j < 20; j++) {
                if (floodGrid[i][j] == l){
                    lowerGrid[i][j] = 7;
                    heightGrid[i][j] = -0.4f;
                }
            }
        }
    }
}

void checkCrackquake() {

    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            floodGrid[i][j] = 0;
        }
    }

    for (i = 0; i < 20; i++) {
        floodAmount[i] = 0;
    }

    k = 1;
    l = 1;

    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            if (((lowerGrid[i][j] == 4) ||  (lowerGrid[i][j] == 5)) && (floodGrid[i][j] == 0)) {
                cancelFlood = false;
                floodCrackArea(i,j,k);
                if (cancelFlood) {
                    floodAmount[k] = 10000;
                }
                k = k + 1;
            }
        }
    }

    for (i = 1; i<k; i++){
        if (floodAmount[i] < floodAmount[l])
            l = i;
    }

    if (floodAmount[l] < 1000){
        for (i = 0; i < 20; i++) {
            for (j = 0; j < 20; j++) {
                if (floodGrid[i][j] == l && lowerGrid[i][j] == 4){
                    lowerGrid[i][j] = 8;
                    heightGrid[i][j] = -0.4f;
                }
                if (floodGrid[i][j] == l && lowerGrid[i][j] == 5){
                    lowerGrid[i][j] = 9;
                    heightGrid[i][j] = -0.4f;
                }
            }
        }
    }
}

void checkCamDistance() {

    if (zPressed)
        if (cam1arm > 4.0)
        cam1arm = cam1arm - 0.1;
    if (xPressed)
        if (cam1arm < 14.0)
        cam1arm = cam1arm + 0.1;

}

void updateHeightGrid() {

    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            if (heightGrid[i][j] < 0.0f){
                speedGrid[i][j] = speedGrid[i][j] + 0.01;
                heightGrid[i][j] = heightGrid[i][j] - speedGrid[i][j];
                }
            if (heightGrid[i][j] < -10.0f){
                heightGrid[i][j] = 0.0f;
                lowerGrid[i][j] = 0;
                upperGrid[i][j] = 0;
            }
        }
    }
}

void floodArea(int i, int j, int k) {

    floodGrid[i][j] = k;
    floodAmount[k] = floodAmount[k] + 1;

    if ((lowerGrid[i+1][j] == 1) && (floodGrid[i+1][j] == 0))
        floodArea(i+1,j,k);

    if ((lowerGrid[i-1][j] == 1) && (floodGrid[i-1][j] == 0))
        floodArea(i-1,j,k);

    if ((lowerGrid[i][j+1] == 1) && (floodGrid[i][j+1] == 0))
        floodArea(i,j+1,k);

    if ((lowerGrid[i][j-1] == 1) && (floodGrid[i][j-1] == 0))
        floodArea(i,j-1,k);

}

void floodCrackArea(int i, int j, int k) {

    floodGrid[i][j] = k;
    floodAmount[k] = floodAmount[k] + 1;

    if ((lowerGrid[i+1][j] == 4) && (floodGrid[i+1][j] == 0))
        floodCrackArea(i+1,j,k);

    if ((lowerGrid[i-1][j] == 4) && (floodGrid[i-1][j] == 0))
        floodCrackArea(i-1,j,k);

    if ((lowerGrid[i][j+1] == 4) && (floodGrid[i][j+1] == 0))
        floodCrackArea(i,j+1,k);

    if ((lowerGrid[i][j-1] == 4) && (floodGrid[i][j-1] == 0))
        floodCrackArea(i,j-1,k);

    if ((lowerGrid[i+1][j] == 5) && (floodGrid[i+1][j] == 0))
        floodCrackArea(i+1,j,k);

    if ((lowerGrid[i-1][j] == 5) && (floodGrid[i-1][j] == 0))
        floodCrackArea(i-1,j,k);

    if ((lowerGrid[i][j+1] == 5) && (floodGrid[i][j+1] == 0))
        floodCrackArea(i,j+1,k);

    if ((lowerGrid[i][j-1] == 5) && (floodGrid[i][j-1] == 0))
        floodCrackArea(i,j-1,k);

    if (lowerGrid[i+1][j] == 1)
        cancelFlood = true;

    if (lowerGrid[i-1][j] == 1)
        cancelFlood = true;

    if (lowerGrid[i][j+1] == 1)
        cancelFlood = true;

    if (lowerGrid[i][j-1] == 1)
        cancelFlood = true;

}

void updateEnemiesState() {

    checkEnemyCollision();
	updateEnemyPosition();

}

void updateEnemyPosition() {

    for(i = 0; i<4; i++) {
        if (enemyAlive[i] == true) {
                if (!enemyAiFlag[i])
                    aiChooseSide(i);
                if (queueRotYenemy[i] != rotYenemy[i])
                    rotateEnemy(i); else
                moveEnemy(i);
        }
    }
}

void aiChooseSide(int e) {

    j = 0;

    if (((lowerGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] != 1) || (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] == 6) || (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] == 3))
        && ((lowerGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] != 1) || (upperGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] == 6) || (upperGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] == 3))
    && ((lowerGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] != 1) || (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] == 6) || (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] == 3))
        && ((lowerGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] != 1) || (upperGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] == 6) || (upperGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] == 3)))
        j = 1;
        enemySide[e] = 4;

    while(j == 0) {

        enemySide[e] = rand();
        switch (enemySide[e]) {

        case 0: if ((lowerGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] == 1) && (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] != 6) && (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] - 1] != 3)) {
                    j = 1;
                }
                break;
        case 1: if ((lowerGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] == 1) && (upperGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] != 6) && (upperGrid[enemyGrid[e][0] + 1][enemyGrid[e][1]] != 3)) {
                    j = 1;
                }
                break;
        case 2: if ((lowerGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] == 1) && (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] != 6) && (upperGrid[enemyGrid[e][0]][enemyGrid[e][1] + 1] != 3)) {
                    j = 1;
                }
                break;
        case 3: if ((lowerGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] == 1) && (upperGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] != 6) && (upperGrid[enemyGrid[e][0] - 1][enemyGrid[e][1]] != 3)) {
                    j = 1;
                }
                break;
        }

    }

    enemyAiFlag[e] = true;
    queueRotYenemy[e] = enemySide[e] * 90;

}

void rotateEnemy (int e) {
        if (queueRotYenemy[e] > rotYenemy[e]) {
            rotYenemy[e] = rotYenemy[e] + 10.0f;
        }
        if (queueRotYenemy[e] < rotYenemy[e]) {
            rotYenemy[e] = rotYenemy[e] - 10.0f;
        }
}

void moveEnemy(int e) {

    switch (enemySide[e]) {
    case 0:
        speedXenemy[e] = 0.0;
        speedZenemy[e] = -0.05;
        break;
    case 1:
        speedXenemy[e] = 0.05;
        speedZenemy[e] = 0.0;
        break;
    case 2:
        speedXenemy[e] = 0.0;
        speedZenemy[e] = 0.05;
        break;
    case 3:
        speedXenemy[e] = -0.05;
        speedZenemy[e] = 0.0;
        break;
    case 4:
        speedXenemy[e] = 0.0;
        speedZenemy[e] = 0.0;
        break;
    }

    posXenemy[e] = posXenemy[e] + speedXenemy[e];
    posZenemy[e] = posZenemy[e] + speedZenemy[e];

    movesEnemy[e] = movesEnemy[e] + 1;
    if (movesEnemy[e] == 80) {
        movesEnemy[e] = 0;
        enemyAiFlag[e] = false;
    }


}

void checkEnemyCollision() {

    collisionX = 0;
    collisionZ = 0;
    collisionX = collisionX - (float)grassExtension/2;
    collisionZ = collisionZ - (float)grassExtension/2;

    for (i = 0; i<4; i++){
        if (enemyAlive[i] == 1) {
            for (k = 0; k<20; k++) {
                for (l = 0; l<20; l++) {
                        if(lowerGrid[k][l] == 0 || lowerGrid[k][l] == 7 || lowerGrid[k][l] == 8 || lowerGrid[k][l] == 9){
                                if((collisionX < posXenemy[i]) && (posXenemy[i] < collisionX + (float)grassExtension) && (collisionZ < posZenemy[i]) && (posZenemy[i] < collisionZ + (float)grassExtension)) {
                                    fellWaterEnemy[i] = true;
                                }
                        }
                        if((collisionX < posXenemy[i]) && (posXenemy[i] < collisionX + (float)grassExtension) && (collisionZ < posZenemy[i]) && (posZenemy[i] < collisionZ + (float)grassExtension)) {
                            enemyGrid[i][0] = k;
                            enemyGrid[i][1] = l;
                        }
                        collisionZ = collisionZ + (float)grassExtension;
                }
                collisionZ = collisionZ - (float)grassExtension*20;
                collisionX = collisionX + (float)grassExtension;
            }
        }
        collisionX = 0;
        collisionZ = 0;
        collisionX = collisionX - (float)grassExtension/2;
        collisionZ = collisionZ - (float)grassExtension/2;
    }

    for (i = 0; i<4; i++){
        if (enemyAlive[i] == 1){

            posYenemy[i] = posYenemy[i] - speedYenemy[i];
            if (posYenemy[i] < heightLimit) {
                posYenemy[i] = heightLimit;
                speedYenemy[i] = 0.0f;
                enemyAlive[i] = 0;
                enemiesAlive = enemiesAlive - 1;
            }

            if (fellWaterEnemy[i]){
                speedYenemy[i] = speedYenemy[i] + 0.01;
            }
        }
    }

}

void gameEnded() {

    rightPressed = false;
    rightFlag = false;
    leftPressed = false;
    leftFlag = false;
    upPressed = false;
    downPressed = false;
    spacePressed = false;
    spaceFlag = false;
    vPressed = false;
    vFlag = false;

    countingDown = true;

    m = m + 1;
	if (m == 79 && (countDown > 0)) {
        m = 0;
        countDown = countDown - 1;
	}

    if (countDown == 0) {
        if (!wonStage || gameStage == 9)
            onMenu = true;
        else {
            gameStage = gameStage + 1;
            stageInit();
        }
    }
}

///MAIN FUNCTIONS
void mainRender() {

    if (onMenu) {
        updateMenu();
        glScissor(0, 0, windowWidth, windowHeight);
        glViewport(0, 0, windowWidth, windowHeight);
        renderMenu();
    } else {
	updateState();
	updateEnemiesState();
	glScissor(0, 0, windowWidth, windowHeight);
    glViewport(0, 0, windowWidth, windowHeight);
	renderScene();
	glScissor(0, 0, windowWidth/5, windowHeight/5);
	glViewport(0, 0, windowWidth/5, windowHeight/5);
	renderMinimap();
    }
	glFlush();
	glutPostRedisplay();
	Sleep(fpsSpeed);

}

void onKeyDown(unsigned char key, int x, int y) {
	switch (key) {
		case 32: //space
			if (spacePressed) {

			}
			spacePressed = true;
			break;
		case 119: //w
			upPressed = true;
			break;
		case 115: //s
			downPressed = true;
			break;
		case 97: //a
			leftPressed = true;
			break;
		case 100: //d
			rightPressed = true;
			break;
		case 114: //r
			running = true;
			break;
        case 118: //v
			vPressed = true;
			break;
        case 122: //z
            zPressed = true;
            break;
        case 120: //x
            xPressed = true;
            break;
        case 13: //x
            enterPressed = true;
            break;
		default:
			break;
	}

	//glutPostRedisplay();
}

void onKeyUp(unsigned char key, int x, int y) {
	switch (key) {
		case 32: //space
			spacePressed = false;
			break;
		case 119: //w
			upPressed = false;
			break;
		case 115: //s
			downPressed = false;
			break;
		case 97: //a
			leftPressed = false;
			break;
		case 100: //d
			rightPressed = false;
			break;
		case 114: //r
			running = false;
			break;
        case 118: //v
			vPressed = false;
			break;
        case 122: //z
            zPressed = false;
            break;
        case 120: //x
            xPressed = false;
            break;
		case 27:
			exit(0);
			break;
        case 13: //x
            enterPressed = false;
            break;
		default:
			break;
	}

	//glutPostRedisplay();
}

void specialInputDown(int key, int x, int y) {

    switch (key) {
		case GLUT_KEY_UP: //w
			upPressed = true;
			break;
		case GLUT_KEY_DOWN: //s
			downPressed = true;
			break;
		case GLUT_KEY_LEFT: //a
			leftPressed = true;
			break;
		case GLUT_KEY_RIGHT: //d
			rightPressed = true;
			break;
        }

}

void specialInputUp(int key, int x, int y) {

    switch (key) {
		case GLUT_KEY_UP: //w
			upPressed = false;
			break;
		case GLUT_KEY_DOWN: //s
			downPressed = false;
			break;
		case GLUT_KEY_LEFT: //a
			leftPressed = false;
			break;
		case GLUT_KEY_RIGHT: //d
			rightPressed = false;
			break;
    }

}

void onWindowReshape(int x, int y) {
	windowWidth = x;
	windowHeight = y;
	setWindow();
	setViewport(0, windowWidth, 0, windowHeight);
}

void mainIdle() {
	/**
	Set the active window before send an glutPostRedisplay call
	so it wont be accidently sent to the glui window
	*/

	glutSetWindow(mainWindowId);
	glutPostRedisplay();
}

int main(int argc, char **argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(windowWidth,windowHeight);
	glutInitWindowPosition(windowXPos,windowYPos);

	/**
	Store main window id so that glui can send it redisplay events
	*/
	mainWindowId = glutCreateWindow("DDII: Apples and Oranges");

	glutDisplayFunc(mainRender);

	glutReshapeFunc(onWindowReshape);

	/**
	Register keyboard events handlers
	*/
	glutSpecialFunc(specialInputDown);
	glutSpecialUpFunc(specialInputUp);
	glutKeyboardFunc(onKeyDown);
	glutKeyboardUpFunc(onKeyUp);

	mainInit();
	glutMainLoop();

    return 0;
}

